#ifndef FILTROFOTO_H
#define FILTROFOTO_H

#include <QDialog>
#include <QWidget>
#include <QTime>
#include <sstream>
#include <string.h>
#include <qfiledialog.h>
#include "ctime"
#include "iostream"
#include "stdlib.h"
#include "QTime"
#include "ctime"
#include "unistd.h"
#include "mainwindow.h"


namespace Ui {
class FiltroFoto;
}

class FiltroFoto : public QDialog
{
    Q_OBJECT

public:
    explicit FiltroFoto(QWidget *parent = 0);
    ~FiltroFoto();
    QTime tiempo;
    QString path;
    QTime time;

    int nTime = 1;
    double media =0;
    void cargarFoto(QImage* foto);

private slots:
    void on_Boton_Calcular_clicked();

    void on_Boton_Calcular_2_clicked();

    void on_Boton_Calcular_3_clicked();

    void on_Boton_Calcular_4_clicked();

private:
    Ui::FiltroFoto *ui;
};

#endif // FILTROFOTO_H
