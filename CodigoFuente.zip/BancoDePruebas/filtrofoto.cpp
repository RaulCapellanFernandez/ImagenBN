#include "filtrofoto.h"
#include "ui_filtrofoto.h"
#include "math.h"

FiltroFoto::FiltroFoto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FiltroFoto)
{
    ui->setupUi(this);
}

FiltroFoto::~FiltroFoto()
{
    delete ui;
}

void FiltroFoto::on_Boton_Calcular_clicked()
{
    path = QFileDialog::getOpenFileName(this,tr("elige"),".",tr("*jpg *png"));
    QImage *imagen =new QImage();
    imagen->load(path);
    ui->ImagenOrigin->setPixmap(QPixmap(path));
}

void FiltroFoto::on_Boton_Calcular_2_clicked()
{
    tiempo.start();
    tiempo.msecsSinceStartOfDay();


    unsigned time0 = clock();
    QImage *imagen = new QImage();
    imagen->load(path);
    QImage SEP = imagen->convertToFormat(QImage::Format_Grayscale8);
    SEP.save("SEP.jpg","JPG");
    ui->ImagenTrans->setPixmap(QPixmap::fromImage(SEP));
    unsigned time1 = clock();
    double time = (double(time1-time0)/CLOCKS_PER_SEC);

    if(nTime == 1){
        ui->Etiqueta_SOL1->setNum(time);
        nTime++;
        media = media + time;
    }
   else if(nTime == 2){
        ui->Etiqueta_SOL2->setNum(time);
        nTime++;
        media = media + time;
    }
    else if(nTime == 3){
        ui->Etiqueta_SOL3->setNum(time);
        nTime++;
        media = media + time;
    }
    else if(nTime == 4){
        ui->Etiqueta_SOL4->setNum(time);
        nTime++;
        media = media + time;
    }
    else if(nTime == 5){
        ui->Etiqueta_SOL5->setNum(time);
        nTime++;
        media = media + time;
        media = media/5;
        ui->Etiqueta_MEDIA_2->setNum(media);
    }
}

void FiltroFoto::on_Boton_Calcular_3_clicked()
{
    close();
}

void FiltroFoto::on_Boton_Calcular_4_clicked()
{
    close();
    MainWindow *ventana = new MainWindow();
    ventana->show();
}
