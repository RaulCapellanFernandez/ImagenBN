#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "iostream"
#include "string"
#include "stdlib.h"
#include "QTime"
#include "filtrofoto.h"
#include "ctime"
#include "unistd.h"
#include <stdlib.h>


using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QTime tiempo;

    int nTiempo=1 ;

    int milisegundos;

     double media = 0;

    void calcularFactorial(int factorial);

private slots:
    void on_Boton_Calcular_clicked();

    void on_Boton_Algoritmo_clicked();

    void on_Boton_Calcular_2_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
