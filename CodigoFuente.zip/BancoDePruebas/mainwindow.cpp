#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "math.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Boton_Calcular_clicked()
{
    tiempo.start();
    tiempo.msecsSinceStartOfDay();



    unsigned time0 = clock();
    calcularFactorial(100);
    unsigned time1 = clock();
    double time = (double(time1-time0)/CLOCKS_PER_SEC);

    if(nTiempo == 1){
        ui->Etiqueta_SOL1->setNum(time);
        media = media + time;
        nTiempo++;
    }

    else if(nTiempo == 2){
        ui->Etiqueta_SOL2->setNum(time);
        media = media + time;
        nTiempo++;
    }

    else if(nTiempo == 3){
        ui->Etiqueta_SOL3->setNum(time);
        media = media + time;
        nTiempo++;
    }

    else if(nTiempo == 4){
        ui->Etiqueta_SOL4->setNum(time);
        media = media + time;
        nTiempo++;
    }

    else if(nTiempo == 5){
        ui->Etiqueta_SOL5->setNum(time);
        media = media + time;
        cout<<media<<endl;
        media = media/5;
        ui->Etiqueta_MEDIA_SOL->setNum(media);
        nTiempo ++;
    }

}

void MainWindow::calcularFactorial(int factorial){

    double aux  = 1;
    while(factorial!=0){
        usleep(1000);
        aux = aux*factorial;
        factorial--;
    }

    cout<<aux<<endl;
}

void MainWindow::on_Boton_Algoritmo_clicked()
{
    FiltroFoto *window = new FiltroFoto;
    window->show();
    close();
}

void MainWindow::on_Boton_Calcular_2_clicked()
{
    close();
}
